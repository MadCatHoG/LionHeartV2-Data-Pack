# LionHeartV2-Data-Pack
 Custom recipes for the Lionheart Server. Includes global dyeing recipes.

 Recipes here: https://www.madcatgaming.com/lionheart-custom-recipes/
